(function() {
var glossary =  {"type":"glossary","chunkinfos":[{"type":"chunkinfo","first":"","last":"","num":"0","node":"gdata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
