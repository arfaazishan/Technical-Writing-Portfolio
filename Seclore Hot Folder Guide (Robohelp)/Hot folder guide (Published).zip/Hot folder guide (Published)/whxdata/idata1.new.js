(function() {
var index =  {"type":"data","keys":[]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
